
import Exercicio3.Ingresso;


public class TesteIngresso {
    public static void main(String[]args){
        
        Ingresso in = new Ingresso() {
            @Override
            public void ImprimiValor(double valor) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        
    }
    
    
}
