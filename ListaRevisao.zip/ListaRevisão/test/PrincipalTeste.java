import javax.swing.JOptionPane;
import Exercicio1.AssistenteAdm;
import Exercicio1.AssistenteTecnico;


public class PrincipalTeste {
    
    public static void main (String[]args){
       
    AssistenteAdm ad = new AssistenteAdm();
    AssistenteTecnico at = new AssistenteTecnico();
        
        
    String nome = JOptionPane.showInputDialog(null,"digite seu nome");
    String sobrenome = JOptionPane.showInputDialog(null,"digte seu sobrenome");
    String endereco = JOptionPane.showInputDialog(null,"digite seu endereco");
    String mat = JOptionPane.showInputDialog(null,"digite sua matricula");
    
    
    
     ad.ExibeMatricula(mat);
     ad.ExibeDados(mat, sobrenome, endereco);
    
    
    
    
    
        
    }
     
   
    
    
  
    
}
