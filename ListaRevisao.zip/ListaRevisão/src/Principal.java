import javax.swing.JOptionPane;
public class Principal {
    public static void main (String[]args){
       
        
       String nome = JOptionPane.showInputDialog(null,"Qual o seu nome?");
        
         
       
       CartaoWeb[] cartoes = new CartaoWeb[3];
       cartoes[0] = new DiadosNamorados();
       cartoes[1] = new Natal();
       cartoes[2] = new Aniversario();
       
     
       cartoes[0].retonarMensagem(nome);
       cartoes[1].retonarMensagem(nome);
       cartoes[2].retonarMensagem(nome);
           
       }
      
       
        
       
       
        
        
        
        
        
        
    }
}
