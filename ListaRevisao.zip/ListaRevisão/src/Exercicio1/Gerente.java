
package Exercicio1;


public class Gerente extends Funcionario {
    public String matricula;

    @Override
    public void ExibeDados(String nome, String sobrenome, String endereco) {
       
    }
    
  
  }
  
 

    
 
    

