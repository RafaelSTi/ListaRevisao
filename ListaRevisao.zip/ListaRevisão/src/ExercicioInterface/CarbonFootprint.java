
package ExercicioInterface;


public interface CarbonFootprint {
    
    /**
     *
     */
    public void getCarbonFootprint();
    
    }
    
    

